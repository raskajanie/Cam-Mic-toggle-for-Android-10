SKIPUNZIP=0
# Author: raskajanie
. "$MODPATH/lang.sh"
apply_prop "$MODPATH/module.prop"

ui_print "$M_TITLE"
ui_print "$M_LANG"
ui_print "$M_AUTHOR"
ui_print "$M_LAYERS"
for m in /data/adb/modules/*; do
  [ -f "$m/module.prop" ] || continue
  [ "$(basename $m)" = sensor_tiles ] && continue
  if grep -qiE 'sensor.?privacy|privacy.?toggle|mic.*cam' "$m/module.prop" 2>/dev/null; then
    ui_print "$M_SIMILAR $(basename $m)"
    ui_print "$M_CONFLICT"
  fi
done
set_perm "$MODPATH/sensors.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/lang.sh" 0 0 0755
ui_print "$M_AFTER"
ui_print "$M_TILES"
ui_print "$M_WARN"
