#!/system/bin/sh
# Author: raskajanie
# usage: sensors.sh <mic|cam> <block|unblock|toggle|status|info>
#        sensors.sh daemon
#
# Полная блокировка микрофона / камеры для ВСЕХ процессов, пока не нажмёшь плитку снова.
# Три слоя:
#  1) Android 12+: системный sensor_privacy (как кнопка "Доступ к микрофону/камере" в шторке) —
#     глушит датчик на уровне фреймворка для всех приложений и всех пользователей.
#  2) AppOps (uid-mode=ignore) для ВСЕХ приложений uid>=10000 (системные, Google, новые,
#     без выданного разрешения — тоже). Прошлые режимы сохраняются и точно восстанавливаются.
#  3) Фоновый сторож: ловит новые установки и сброс AppOps (например, при выдаче разрешения)
#     и сразу блокирует заново.
# Интерфейс для приложения плиток не менялся: в stdout печатается ровно blocked / allowed.

D=${ST_DIR:-/data/adb/sensor_tiles}
SELF=$0
TICK=5        # период сторожа, сек
VERIFY=12     # полная перепроверка каждые VERIFY*TICK сек
JOBS=12       # параллельных вызовов cmd
mkdir -p "$D"

log() { echo "$(date +%m-%d_%T) $*" >> "$D/log.txt" 2>/dev/null; }

users() {
  u=$(pm list users 2>/dev/null | sed -n 's/.*UserInfo{\([0-9]*\):.*/\1/p')
  [ -z "$u" ] && u=0
  echo $u
}

daemon() {
  PF=$D/daemon.pid
  if [ -f "$PF" ]; then
    op=$(cat "$PF" 2>/dev/null)
    if [ -n "$op" ] && grep -q sensors.sh "/proc/$op/cmdline" 2>/dev/null; then exit 0; fi
  fi
  echo $$ > "$PF"
  if [ -f "$D/log.txt" ] && [ "$(wc -c < "$D/log.txt")" -gt 200000 ]; then
    tail -n 300 "$D/log.txt" > "$D/log.tmp" && mv "$D/log.tmp" "$D/log.txt"
  fi
  MODDIR=${SELF%/*}
  LASTLANG=$(getprop persist.sys.locale 2>/dev/null)$(getprop persist.sys.language 2>/dev/null)
  n=0
  while :; do
    sleep $TICK
    n=$((n+1))
    # смена языка системы -> обновить название/описание модуля в Magisk (плитки сами берут язык при каждом показе)
    cur=$(getprop persist.sys.locale 2>/dev/null)$(getprop persist.sys.language 2>/dev/null)
    if [ "$cur" != "$LASTLANG" ]; then
      LASTLANG=$cur
      [ -f "$MODDIR/lang.sh" ] && ( . "$MODDIR/lang.sh"; apply_prop "$MODDIR/module.prop"; log "lang -> $LANG_CODE" )
    fi
    for s in mic cam; do
      [ -f "$D/$s.blocked" ] || continue
      if [ $((n % VERIFY)) -eq 0 ]; then sh "$SELF" $s sync full; else sh "$SELF" $s sync; fi
    done
  done
}

S=$1; A=$2
case $S in
  mic) OP=RECORD_AUDIO; SP=microphone ;;
  cam) OP=CAMERA;       SP=camera ;;
  daemon) daemon; exit 0 ;;
  *) echo "usage: $0 <mic|cam> <block|unblock|toggle|status|info> | daemon"; exit 2 ;;
esac
ST=$D/$S.d
MK=$D/$S.blocked
LK=$D/$S.lock

lock() {
  i=0
  while ! mkdir "$LK" 2>/dev/null; do
    i=$((i+1))
    if [ $i -gt 600 ]; then rm -rf "$LK"; mkdir "$LK" 2>/dev/null; break; fi
    sleep 0.1
  done
  trap 'rmdir "$LK" 2>/dev/null' EXIT INT TERM
}
unlock() { rmdir "$LK" 2>/dev/null; }

get_mode() { # user pkg
  m=$(cmd appops get --user "$1" --uid "$2" $OP 2>/dev/null | grep -m1 '^Uid mode:' | sed 's/.*: *//' | tr -d ' \r')
  case $m in allow|ignore|deny|default|foreground|errored) ;; *) m=default ;; esac
  echo $m
}
set_mode() { cmd appops set --user "$1" --uid "$2" $OP "$3" >/dev/null 2>&1; } # user pkg mode

# "user uid pkg" для всех приложений (включая системные и отключённые) с uid >= 10000
list_apps() {
  for u in $(users); do
    cmd package list packages -U --user $u 2>/dev/null \
      | sed -n 's/^package:\([^ ]*\) uid:\([0-9]*\).*/\2 \1/p' \
      | while read -r uid pkg; do
          [ -n "$uid" ] || continue
          [ $((uid % 100000)) -ge 10000 ] && echo "$u $uid $pkg"
        done
  done
}

# слой 1: системный sensor_privacy (Android 12+)
sp_set() { # enable|disable
  [ "$(getprop ro.build.version.sdk)" -ge 31 ] 2>/dev/null || return 0
  cmd -l 2>/dev/null | grep -q sensor_privacy || return 0
  for u in $(users); do
    out=$(cmd sensor_privacy $1 $u $SP 2>&1); rc=$?
    log "$S sensor_privacy $1 user=$u rc=$rc $out"
  done
}

# слой 2: AppOps для новых приложений (которых ещё нет в состоянии)
apply_new() {
  mkdir -p "$ST"
  list_apps > "$D/$S.apps"
  n=0
  while read -r u uid pkg; do
    [ -f "$ST/$uid" ] && continue
    : > "$ST/$uid"            # занимаем сразу, чтобы не дублировать
    (
      m=$(get_mode $u $pkg)
      echo "$u $pkg $m" > "$ST/$uid"
      case $m in ignore|deny|errored) ;; *) set_mode $u $pkg ignore ;; esac
    ) &
    n=$((n+1)); [ $((n % JOBS)) -eq 0 ] && wait
  done < "$D/$S.apps"
  wait
  rm -f "$D/$S.apps"
}

# слой 2: вернуть ignore, если кто-то сбросил (выдача разрешения и т.п.)
verify() {
  n=0
  for f in "$ST"/*; do
    [ -f "$f" ] || continue
    read -r u pkg m < "$f"
    [ -n "$pkg" ] || continue
    (
      cur=$(get_mode $u $pkg)
      case $cur in ignore|deny|errored) ;; *) set_mode $u $pkg ignore; log "$S re-blocked $pkg (was $cur)" ;; esac
    ) &
    n=$((n+1)); [ $((n % JOBS)) -eq 0 ] && wait
  done
  wait
}

do_block() {
  touch "$MK"
  sp_set enable
  verify
  apply_new
}

do_unblock() {
  sp_set disable
  n=0
  for f in "$ST"/*; do
    [ -f "$f" ] || continue
    read -r u pkg m < "$f"
    [ -n "$pkg" ] || continue
    case $m in errored) continue ;; esac
    set_mode $u $pkg "${m:-default}" &
    n=$((n+1)); [ $((n % JOBS)) -eq 0 ] && wait
  done
  wait
  rm -rf "$ST" "$MK"
  [ "$S" = mic ] && [ -z "$NOFIX" ] && mic_fix
}

# фикс микрофона после включения (из micfix2.sh): "Сбой записи" без него
mic_fix() {
  P=com.sec.android.app.camera
  # 1. цикл вкл/выкл через сам сервис (дёргает слушателей камеры/аудио)
  service call sensor_privacy 4 i32 1 >/dev/null 2>&1; sleep 2
  service call sensor_privacy 4 i32 0 >/dev/null 2>&1; sleep 1
  [ -f /data/system/sensor_privacy.xml ] && sed -i 's/enabled="true"/enabled="false"/' /data/system/sensor_privacy.xml
  # 2. разрешения
  for pk in $P com.google.android.apps.recorder com.sec.android.app.voicenote; do
    pm grant $pk android.permission.RECORD_AUDIO >/dev/null 2>&1
    pm grant $pk android.permission.CAMERA >/dev/null 2>&1
    cmd appops set $pk RECORD_AUDIO allow >/dev/null 2>&1
  done
  # 3. снять возможный mute
  cmd appops set --uid $P RECORD_AUDIO allow >/dev/null 2>&1
  # фикс сбрасывает общий sensor_privacy — если камера заблокирована, вернуть её блокировку
  [ -f "$D/cam.blocked" ] && sh "$SELF" cam block >/dev/null 2>&1
}

info() {
  echo "sdk: $(getprop ro.build.version.sdk)"
  echo "sensor_privacy service: $(cmd -l 2>/dev/null | grep -c sensor_privacy)"
  echo "tracked uids: $(ls "$ST" 2>/dev/null | wc -l)"
  echo "daemon: $(cat "$D/daemon.pid" 2>/dev/null)"
  echo "--- log"; tail -n 20 "$D/log.txt" 2>/dev/null
}

[ "$A" = toggle ] && { [ -f "$MK" ] && A=unblock || A=block; }
case $A in
  block)   lock; do_block; unlock ;;
  unblock) lock; do_unblock; unlock ;;
  sync)    [ -f "$MK" ] || exit 0
           lock
           if [ -f "$MK" ]; then apply_new; [ "$3" = full ] && verify; fi
           unlock; exit 0 ;;
  info)    info; exit 0 ;;
  status|"") ;;
  *) echo "bad action"; exit 2 ;;
esac
[ -f "$MK" ] && echo blocked || echo allowed
