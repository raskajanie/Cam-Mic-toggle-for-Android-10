#!/system/bin/sh
# Author: raskajanie
# Language detection + localized strings (ru en de es it fr zh ja pt). Fallback: en.

detect_lang() {
  LANG_CODE=en
  for _p in persist.sys.locale ro.product.locale persist.sys.language ro.product.locale.language; do
    _all=$(getprop $_p 2>/dev/null | tr -d '\r')
    [ -n "$_all" ] || continue
    # список языков через запятую (ru-RU,en-US): берём первый поддерживаемый, как это делает Android
    _ifs=$IFS; IFS=,
    for _l in $_all; do
      _l=${_l%%[-_]*}
      _l=$(echo "$_l" | tr 'A-Z' 'a-z')
      case $_l in
        ru|en|de|es|it|fr|zh|ja|pt) LANG_CODE=$_l; break ;;
      esac
    done
    IFS=$_ifs
    break
  done
}

load_lang() {
  case $LANG_CODE in
  ru)
    M_LANG="- Язык: Русский"
    MOD_NAME="Sensor Tiles (плитки микрофона и камеры)"
    MOD_DESC="Плитки в шторке: полная блокировка микрофона и камеры для всех процессов (sensor_privacy + AppOps + сторож), пока не включишь обратно."
    M_TITLE="- Sensor Tiles: плитки микрофона и камеры"
    M_LAYERS="  Блокировка для ВСЕХ процессов: sensor_privacy (Android 12+) + AppOps + сторож"
    M_SIMILAR="! Найден похожий модуль:"
    M_CONFLICT="! Отключи/удали его, иначе будут конфликты"
    M_AFTER="- После перезагрузки: шторка -> редактировать -> добавить"
    M_TILES="  'Доступ к микрофону' и 'Доступ к камере'"
    M_WARN="- Перед отключением модуля сначала разблокируй плитки!"
    M_AUTHOR="- Автор: raskajanie" ;;
  es)
    M_LANG="- Idioma: Español"
    MOD_NAME="Sensor Tiles (mosaicos de micrófono y cámara)"
    MOD_DESC="Mosaicos en los ajustes rápidos: bloqueo total del micrófono y la cámara para todos los procesos (sensor_privacy + AppOps + vigilante) hasta que los reactives."
    M_TITLE="- Sensor Tiles: mosaicos de micrófono y cámara"
    M_LAYERS="  Bloqueo para TODOS los procesos: sensor_privacy (Android 12+) + AppOps + vigilante"
    M_SIMILAR="! Se encontró un módulo similar:"
    M_CONFLICT="! Desactívalo o elimínalo, de lo contrario habrá conflictos"
    M_AFTER="- Tras reiniciar: ajustes rápidos -> editar -> añadir"
    M_TILES="  'Acceso al micrófono' y 'Acceso a la cámara'"
    M_WARN="- ¡Antes de desactivar el módulo, desbloquea primero los mosaicos!"
    M_AUTHOR="- Autor: raskajanie" ;;
  it)
    M_LANG="- Lingua: Italiano"
    MOD_NAME="Sensor Tiles (riquadri microfono e fotocamera)"
    MOD_DESC="Riquadri nelle impostazioni rapide: blocco totale di microfono e fotocamera per tutti i processi (sensor_privacy + AppOps + watchdog) finché non li riattivi."
    M_TITLE="- Sensor Tiles: riquadri microfono e fotocamera"
    M_LAYERS="  Blocco per TUTTI i processi: sensor_privacy (Android 12+) + AppOps + watchdog"
    M_SIMILAR="! Trovato un modulo simile:"
    M_CONFLICT="! Disattivalo o rimuovilo, altrimenti ci saranno conflitti"
    M_AFTER="- Dopo il riavvio: impostazioni rapide -> modifica -> aggiungi"
    M_TILES="  'Accesso al microfono' e 'Accesso alla fotocamera'"
    M_WARN="- Prima di disattivare il modulo, sblocca i riquadri!"
    M_AUTHOR="- Autore: raskajanie" ;;
  fr)
    M_LANG="- Langue : Français"
    MOD_NAME="Sensor Tiles (tuiles micro et caméra)"
    MOD_DESC="Tuiles des réglages rapides : blocage total du micro et de la caméra pour tous les processus (sensor_privacy + AppOps + surveillant) jusqu'à réactivation."
    M_TITLE="- Sensor Tiles : tuiles micro et caméra"
    M_LAYERS="  Blocage pour TOUS les processus : sensor_privacy (Android 12+) + AppOps + surveillant"
    M_SIMILAR="! Module similaire détecté :"
    M_CONFLICT="! Désactivez-le ou supprimez-le, sinon il y aura des conflits"
    M_AFTER="- Après le redémarrage : réglages rapides -> modifier -> ajouter"
    M_TILES="  « Accès au micro » et « Accès à la caméra »"
    M_WARN="- Avant de désactiver le module, débloquez d'abord les tuiles !"
    M_AUTHOR="- Auteur : raskajanie" ;;
  zh)
    M_LANG="- 语言：中文"
    MOD_NAME="Sensor Tiles（麦克风和摄像头快捷开关）"
    MOD_DESC="快捷设置磁贴：对所有进程完全屏蔽麦克风和摄像头（sensor_privacy + AppOps + 守护进程），直到你重新开启。"
    M_TITLE="- Sensor Tiles：麦克风和摄像头磁贴"
    M_LAYERS="  对所有进程生效：sensor_privacy（Android 12+）+ AppOps + 守护进程"
    M_SIMILAR="! 发现类似模块："
    M_CONFLICT="! 请禁用或删除它，否则会产生冲突"
    M_AFTER="- 重启后：快捷设置 -> 编辑 -> 添加"
    M_TILES="  「麦克风使用权限」和「摄像头使用权限」"
    M_WARN="- 禁用模块前，请先解除磁贴的屏蔽！"
    M_AUTHOR="- 作者：raskajanie" ;;
  ja)
    M_LANG="- 言語：日本語"
    MOD_NAME="Sensor Tiles（マイク・カメラ タイル）"
    MOD_DESC="クイック設定タイル：すべてのプロセスに対してマイクとカメラを完全にブロックします（sensor_privacy + AppOps + 監視デーモン）。再度オンにするまで有効です。"
    M_TITLE="- Sensor Tiles：マイクとカメラのタイル"
    M_LAYERS="  すべてのプロセスをブロック：sensor_privacy（Android 12+）+ AppOps + 監視デーモン"
    M_SIMILAR="! 類似のモジュールが見つかりました："
    M_CONFLICT="! 競合を避けるため、無効化または削除してください"
    M_AFTER="- 再起動後：クイック設定 -> 編集 -> 追加"
    M_TILES="  「マイクへのアクセス」と「カメラへのアクセス」"
    M_WARN="- モジュールを無効にする前に、まずタイルのブロックを解除してください！"
    M_AUTHOR="- 作者：raskajanie" ;;
  pt)
    M_LANG="- Idioma: Português"
    MOD_NAME="Sensor Tiles (blocos de microfone e câmera)"
    MOD_DESC="Blocos nas configurações rápidas: bloqueio total do microfone e da câmera para todos os processos (sensor_privacy + AppOps + vigia) até você reativar."
    M_TITLE="- Sensor Tiles: blocos de microfone e câmera"
    M_LAYERS="  Bloqueio para TODOS os processos: sensor_privacy (Android 12+) + AppOps + vigia"
    M_SIMILAR="! Módulo semelhante encontrado:"
    M_CONFLICT="! Desative ou remova, caso contrário haverá conflitos"
    M_AFTER="- Após reiniciar: configurações rápidas -> editar -> adicionar"
    M_TILES="  'Acesso ao microfone' e 'Acesso à câmera'"
    M_WARN="- Antes de desativar o módulo, desbloqueie os blocos primeiro!"
    M_AUTHOR="- Autor: raskajanie" ;;
  de)
    M_LANG="- Sprache: Deutsch"
    MOD_NAME="Sensor Tiles (Mikrofon- und Kamera-Kacheln)"
    MOD_DESC="Kacheln in den Schnelleinstellungen: vollständige Sperre von Mikrofon und Kamera für alle Prozesse (sensor_privacy + AppOps + Wächter), bis du sie wieder aktivierst."
    M_TITLE="- Sensor Tiles: Mikrofon- und Kamera-Kacheln"
    M_LAYERS="  Sperre für ALLE Prozesse: sensor_privacy (Android 12+) + AppOps + Wächter"
    M_SIMILAR="! Ähnliches Modul gefunden:"
    M_CONFLICT="! Deaktiviere oder entferne es, sonst kommt es zu Konflikten"
    M_AFTER="- Nach dem Neustart: Schnelleinstellungen -> bearbeiten -> hinzufügen"
    M_TILES="  „Mikrofonzugriff“ und „Kamerazugriff“"
    M_WARN="- Vor dem Deaktivieren des Moduls zuerst die Kacheln entsperren!"
    M_AUTHOR="- Autor: raskajanie" ;;
  *)
    M_LANG="- Language: English"
    MOD_NAME="Sensor Tiles (Mic & Camera QS)"
    MOD_DESC="Quick Settings tiles: full microphone and camera block for all processes (sensor_privacy + AppOps + watchdog) until you turn it back on."
    M_TITLE="- Sensor Tiles: microphone and camera tiles"
    M_LAYERS="  Blocks ALL processes: sensor_privacy (Android 12+) + AppOps + watchdog"
    M_SIMILAR="! Similar module found:"
    M_CONFLICT="! Disable/remove it, otherwise conflicts will occur"
    M_AFTER="- After reboot: Quick Settings -> edit -> add"
    M_TILES="  'Microphone access' and 'Camera access'"
    M_WARN="- Unblock the tiles first before disabling the module!"
    M_AUTHOR="- Author: raskajanie" ;;
  esac
}

# rewrite name= and description= in module.prop (keeps other lines)
apply_prop() { # path
  f=$1
  [ -f "$f" ] || return 0
  # уже на нужном языке — ничего не переписываем
  grep -qxF "name=$MOD_NAME" "$f" 2>/dev/null && grep -qxF "description=$MOD_DESC" "$f" 2>/dev/null && return 0
  t="$f.tmp"
  grep -v -E '^(name|description)=' "$f" > "$t" 2>/dev/null || return 0
  echo "name=$MOD_NAME" >> "$t"
  echo "description=$MOD_DESC" >> "$t"
  cat "$t" > "$f" && rm -f "$t"
}

detect_lang
load_lang
