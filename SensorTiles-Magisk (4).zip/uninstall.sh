#!/system/bin/sh
# Author: raskajanie
# Magisk запускает uninstall.sh рано при загрузке, когда cmd/appops ещё недоступны,
# а папка модуля сразу удаляется — поэтому копируем скрипт и доделываем в фоне после загрузки.
cp "${0%/*}/sensors.sh" /data/adb/st_sensors.sh 2>/dev/null
cat > /data/adb/st_cleanup.sh <<'EOT'
#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 3; done
sleep 5
for s in mic cam; do NOFIX=1 sh /data/adb/st_sensors.sh $s unblock >/dev/null 2>&1; done
pm uninstall com.sensortiles >/dev/null 2>&1
rm -rf /data/adb/sensor_tiles /data/adb/st_sensors.sh /data/adb/st_cleanup.sh
EOT
nohup sh /data/adb/st_cleanup.sh >/dev/null 2>&1 &
