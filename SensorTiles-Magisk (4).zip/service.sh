#!/system/bin/sh
# Author: raskajanie
MODDIR=${0%/*}
APK=$MODDIR/system/app/SensorTiles/SensorTiles.apk
PKG=com.sensortiles
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 3; done
sleep 10
# локализация названия/описания модуля под текущий язык телефона (Magisk показывает module.prop)
[ -f "$MODDIR/lang.sh" ] && { . "$MODDIR/lang.sh"; apply_prop "$MODDIR/module.prop"; }
# если система не подхватила APK из /system/app — ставим как обычное приложение;
# также обновляем старую пользовательскую копию (versionCode < 3), если подпись другая — переустановка
if [ -f "$APK" ]; then
  CUR=$(pm path $PKG 2>/dev/null | head -n1)
  VC=$(dumpsys package $PKG 2>/dev/null | sed -n 's/.*versionCode=\([0-9]*\).*/\1/p' | head -n1)
  NEED=""
  case "$CUR" in
    "") NEED=1 ;;
    *"/data/app/"*) [ "${VC:-0}" -lt 3 ] && NEED=1 ;;
  esac
  if [ -n "$NEED" ]; then
    cp "$APK" /data/local/tmp/st.apk
    pm install -r /data/local/tmp/st.apk >/dev/null 2>&1 || { pm uninstall $PKG >/dev/null 2>&1; pm install /data/local/tmp/st.apk >/dev/null 2>&1; }
    rm -f /data/local/tmp/st.apk
  fi
fi
# авто-выдача root приложению плиток (чтобы не было запроса Magisk)
U=$(cmd package list packages -U $PKG 2>/dev/null | sed -n 's/.*uid:\([0-9]*\).*/\1/p' | head -n1)
[ -n "$U" ] && magisk --sqlite "REPLACE INTO policies (uid,policy,until,logging,notification) VALUES($U,2,0,0,0);" >/dev/null 2>&1
# переприменить блокировку (новые приложения, сброс appops)
for s in mic cam; do
  [ -f /data/adb/sensor_tiles/$s.blocked ] && sh $MODDIR/sensors.sh $s block >/dev/null 2>&1
done
# сторож: держит блокировку для новых установок и при сбросе AppOps
rm -f /data/adb/sensor_tiles/*.lock 2>/dev/null; rmdir /data/adb/sensor_tiles/*.lock 2>/dev/null
nohup sh $MODDIR/sensors.sh daemon >/dev/null 2>&1 &
